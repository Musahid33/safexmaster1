'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, Download, Eye, ExternalLink, FileText, Printer, Scale, ScrollText, ShieldAlert,
  type LucideIcon
} from 'lucide-react';
import { LANGUAGE_LOCALE } from '@/lib/i18n';
import { VAULT_CATEGORIES } from '@/lib/content/catalog';
import { registerDate, registerValidity, registerToday } from '@/lib/content/register';
import { appendResourceQuery, safeExternalUrl, safeResourceUrl } from '@/lib/safe-url';
import { useI18n } from './I18nProvider';
import { DOCUMENT_VAULT_CATEGORIES, type VaultCategoryId, type VaultDocument } from './DocumentVault';

/**
 * One vault shelf, shown as the site's document register.
 *
 * The register is the same for every shelf — SOP / SWP, Risk Assessments, Legal & Statutory
 * Compliance and Policy & Procedures: serial number, department, section, document type,
 * document number, document name, validity and status. Rows come only from published database
 * rows; the shelf never fills itself.
 *
 * Viewing a row keeps the reader on this page: the document is streamed from this origin and
 * displayed underneath the register, with Print and Download beside it. Neither action opens a
 * tab — printing goes to the same page's viewer and downloading stays a file download.
 */

/** Per-shelf column wording, so the register speaks the shelf's own language. */
const SHELF_TEXT: Record<VaultCategoryId, { code: string; name: string }> = {
  'sop-swp': { code: 'SOP No.', name: 'SOP Name' },
  'risk-assessments': { code: 'RA No.', name: 'Risk Assessment' },
  'legal-compliance': { code: 'Legal No.', name: 'Compliance Name' },
  'policies-procedures': { code: 'Doc No.', name: 'Policy Name' }
};

const SHELF_ICON: Record<VaultCategoryId, LucideIcon> = {
  'sop-swp': FileText,
  'risk-assessments': ShieldAlert,
  'legal-compliance': Scale,
  'policies-procedures': ScrollText
};

export function VaultShelf({ categoryId, siteName, documents = [], onBack }: {
  categoryId: VaultCategoryId;
  siteName: string;
  documents?: VaultDocument[];
  onBack: () => void;
}) {
  const { language, T } = useI18n();
  const locale = LANGUAGE_LOCALE[language];
  const category = DOCUMENT_VAULT_CATEGORIES.find((item) => item.id === categoryId);
  const [openId, setOpenId] = useState<string | null>(null);
  const detailRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => { setOpenId(null); }, [categoryId]);

  const shelf = useMemo(
    () => documents.filter((document) => document.category === categoryId),
    [documents, categoryId]
  );

  // Opening a row on a phone should land on the document, not leave the reader at the table.
  useEffect(() => {
    if (openId) detailRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [openId]);

  if (!category) return null;

  const text = SHELF_TEXT[categoryId];
  const Icon = SHELF_ICON[categoryId];
  const open = shelf.find((document) => document.id === openId) ?? null;
  const today = registerToday();
  const count = new Intl.NumberFormat(locale).format(shelf.length);
  const openFileUrl = open?.external ? safeExternalUrl(open.fileUrl) : safeResourceUrl(open?.fileUrl);
  const inlinePdfUrl = open && !open.external ? appendResourceQuery(open.fileUrl, 'inline', '1', 'navpanes=0&view=FitH') : null;
  const inlineImageUrl = open && !open.external ? appendResourceQuery(open.fileUrl, 'inline', '1') : null;
  const downloadUrl = open && !open.external ? appendResourceQuery(open.fileUrl, 'download', '1') : null;
  const viewerKind = !openFileUrl || open?.external
    ? 'none'
    : open?.mimeType === 'application/pdf'
      ? 'pdf'
      : open?.mimeType?.startsWith('image/')
        ? 'image'
        : 'none';

  /**
   * Print the document that is already on screen. The viewer is same-origin, so its own frame
   * is what goes to the printer; if the browser refuses that, the page falls back to printing
   * itself (the print stylesheet hides everything except the document).
   */
  function printDocument() {
    const frame = viewerRef.current;
    const target = frame?.contentWindow;
    try {
      if (target) {
        target.focus();
        target.print();
        return;
      }
    } catch {
      // Fall through to printing the page itself.
    }
    window.print();
  }

  return <section className="page-panel vault-shelf-page">
    <button className="vault-shelf-back" type="button" onClick={onBack}><ArrowLeft size={16} /> {T('Document Vault / Library')}</button>

    <div className="vault-shelf-head">
      <span className={`vault-category-icon ${category.tone}`}><Icon size={24} /></span>
      <div className="vault-shelf-head-copy">
        <span className="eyebrow">{T('DOCUMENT VAULT')} · {siteName}</span>
        <h1>{T(category.title)}</h1>
        <p>{T(category.description)} · {T('{count} published', { count })}</p>
      </div>
    </div>

    <div className="vault-register-wrap">
      <table className="vault-register">
        <colgroup>
          <col className="vault-col-sr" />
          <col />
          <col className="vault-col-code" />
          <col className="vault-col-status" />
          <col className="vault-col-action" />
        </colgroup>
        <thead>
          <tr>
            <th scope="col">{T('Sr No.')}</th>
            <th scope="col">{T(text.name)}</th>
            <th scope="col">{T(text.code)}</th>
            <th scope="col">{T('Status')}</th>
            <th scope="col">{T('Action')}</th>
          </tr>
        </thead>
        <tbody>
          {shelf.map((document, index) => {
            const validity = registerValidity(document.validUpto, today);
            return <tr key={document.id} className={openId === document.id ? 'is-open' : ''}>
              <td data-label={T('Sr No.')} className="vault-register-sr">{index + 1}</td>
              <td data-label={T(text.name)} className="vault-register-name">
                <button type="button" onClick={() => setOpenId(document.id)}>{document.title}</button>
              </td>
              <td data-label={T(text.code)} className="vault-register-code">{document.documentCode ?? '—'}</td>
              <td data-label={T('Status')}><span className={`vault-status ${validity.key}`}>{T(validity.label)}</span></td>
              <td data-label={T('Action')} className="vault-register-actions">
                <button
                  type="button"
                  className="vault-view-button"
                  aria-label={T('View {name}', { name: document.title })}
                  aria-expanded={openId === document.id}
                  onClick={() => setOpenId(document.id)}
                ><Eye size={15} /> {T('View')}</button>
              </td>
            </tr>;
          })}
        </tbody>
      </table>
      {shelf.length === 0 && <div className="vault-register-none">
        <b>{T('No documents published yet')}</b>
        <span>{T('Approved files will be listed here once the safety team publishes them from the admin panel.')}</span>
        <span>Content is not connected in the UI preview.</span>
      </div>}
    </div>

    {/* The same five fields as the register, arranged as two aligned lines on a phone:
     * serial number and name, then document number, status and View. */}
    <div className="vault-card-list">
      {shelf.map((document, index) => {
        const validity = registerValidity(document.validUpto, today);
        return <article key={document.id} className={`vault-card ${openId === document.id ? 'is-open' : ''}`}>
          <div className="vault-card-top">
            <span className="vault-card-index">{index + 1}</span>
            <button className="vault-card-name" type="button" onClick={() => setOpenId(document.id)}>{document.title}</button>
          </div>
          <div className="vault-card-meta">
            <span className="vault-card-code"><span>{T(text.code)}</span><b>{document.documentCode ?? '—'}</b></span>
            <span className={`vault-status ${validity.key}`}>{T(validity.label)}</span>
            <button
              type="button"
              className="vault-view-button"
              aria-label={T('View {name}', { name: document.title })}
              aria-expanded={openId === document.id}
              onClick={() => setOpenId(document.id)}
            ><Eye size={14} /> {T('View')}</button>
          </div>
        </article>;
      })}
      {shelf.length === 0 && <div className="vault-register-none">
        <b>{T('No documents published yet')}</b>
        <span>{T('Approved files will be listed here once the safety team publishes them from the admin panel.')}</span>
        <span>Content is not connected in the UI preview.</span>
      </div>}
    </div>

    {open && <div className="vault-detail" ref={detailRef}>
      <button className="vault-detail-back" type="button" onClick={() => setOpenId(null)}><ArrowLeft size={16} /> {T('Back')}</button>
      <div className="vault-detail-head">
        <div className="vault-detail-copy">
          <span className="vault-detail-code">{open.documentCode ?? T(VAULT_CATEGORIES[open.category].title)}</span>
          <h2>{open.title}</h2>
          <p>{open.summary ?? T(VAULT_CATEGORIES[open.category].description)}</p>
          <div className="vault-detail-meta">
            {open.department && <span>{T('Dept.')}: <b>{open.department}</b></span>}
            {open.section && <span>{T('Sec.')}: <b>{open.section}</b></span>}
            <span>{T('Revision')}: <b>{open.revision ?? '—'}</b></span>
            <span>{T('Validity Upto')}: <b>{registerDate(open.validUpto)}</b></span>
            <span className={`vault-status ${registerValidity(open.validUpto, today).key}`}>{T(registerValidity(open.validUpto, today).label)}</span>
          </div>
        </div>
        {downloadUrl && <div className="vault-detail-actions">
          <button
            className="secondary-button"
            type="button"
            onClick={printDocument}
            disabled={viewerKind === 'none'}
          ><Printer size={16} /> {T('Print')}</button>
          <a className="primary-button" href={downloadUrl} download><Download size={16} /> {T('Download')}</a>
        </div>}
      </div>

      {viewerKind === 'pdf' && inlinePdfUrl && <div className="vault-viewer">
        <iframe
          ref={viewerRef}
          key={open.id}
          src={inlinePdfUrl}
          title={open.title}
        />
      </div>}
      {viewerKind === 'image' && inlineImageUrl && <div className="vault-viewer is-image">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={inlineImageUrl} alt={open.title} />
      </div>}
      {openFileUrl && open.external && <a className="vault-detail-link" href={openFileUrl} target="_blank" rel="noopener noreferrer">
        <ExternalLink size={16} /> {T('Open the linked document')}
      </a>}
      {!openFileUrl && <p className="vault-detail-note">{T('No file is attached to this document.')}</p>}
    </div>}
  </section>;
}
