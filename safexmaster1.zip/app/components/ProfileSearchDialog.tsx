'use client';

import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Search, X } from 'lucide-react';
import type { EmployeeDirectory } from '@/lib/employee-directory';
import type { PrivateAccessGateway } from '@/lib/private-access';
import type { DirectoryUnavailableReason, Employee, Site } from '@/lib/types';
import { useI18n } from './I18nProvider';
import EmployeePassport, { type PassportHistory } from './EmployeePassport';

type Props = {
  site: Site | null;
  sites?: readonly Site[];
  companyName?: string | null;
  directory: EmployeeDirectory;
  /** Which source answered, so a test never confuses "not found" with "wrong source". */
  directoryMode?: 'supabase' | 'sheet' | 'unavailable';
  /** Server-side cause when the directory is down; drives an actionable hint. */
  directoryReason?: DirectoryUnavailableReason | null;
  employeeCount?: number;
  onClose: () => void;
  /** Server-backed OTP service for private passport sections; absent means fail closed. */
  privateAccess?: PrivateAccessGateway | null;
  /**
   * Employee ID arriving from a QR scan URL (?emp=…). When present the dialog runs the
   * lookup by itself, so the profile opens without anyone typing the Employee ID.
   */
  autoEmployeeId?: string;
  /** Passed through to the passport so the footer QR points back to this entry path. */
  profileQrPath?: string;
  history?: PassportHistory;
};

const SOURCE_LABEL: Record<'supabase' | 'sheet' | 'unavailable', string> = {
  supabase: 'Live Supabase directory',
  sheet: 'Employee master snapshot',
  unavailable: 'Directory unavailable'
};

/**
 * One sentence per real cause. "Keys are not configured" was misleading when the server
 * key existed but the database was unreachable, so each failure now names itself.
 */
const UNAVAILABLE_HINT: Record<DirectoryUnavailableReason, string> = {
  keys_missing: 'server-side Supabase keys are not configured on this deployment',
  database_unreachable: 'the server could not reach the employee database',
  tenant_unresolved: 'this deployment is not mapped to exactly one tenant',
  no_sites: 'the tenant has no active site configured',
  empty_directory: 'the tenant has no active employees loaded',
  snapshot_unreadable: 'the roster snapshot file could not be read'
};
type UiMessage = { key: string; params?: Record<string, string | number> };

export default function ProfileSearchDialog({ site, sites, companyName, directory, directoryMode, directoryReason, employeeCount = 0, onClose, privateAccess = null, autoEmployeeId, profileQrPath, history }: Props) {
  const { T } = useI18n();
  const [employeeId, setEmployeeId] = useState('');
  const [result, setResult] = useState<Employee | null>(null);
  const [message, setMessage] = useState<UiMessage | null>(null);
  const [searching, setSearching] = useState(false);
  // With no usable source, every search would end as "no profile was found", which reads
  // as a wrong Employee ID. Block the lookup and say what is actually wrong instead.
  const lookupUnavailable = directoryMode === 'unavailable';

  async function runSearch(rawId: string) {
    const id = rawId.trim().toUpperCase();
    if (!id || searching) return;
    setSearching(true);
    setMessage(null);
    try {
      // Company-wide lookup: location does not matter. Any employee of this company
      // opens by Employee ID, whichever site they belong to (empty siteId = all sites).
      const match = await directory.findByEmployeeNo('', id);
      setResult(match);
      setMessage(match ? null : { key: 'No profile was found for {id}. Check the Employee ID and try again.', params: { id } });
    } catch {
      setResult(null);
      setMessage({ key: 'The employee directory is unavailable right now. Try again in a moment.' });
    } finally {
      setSearching(false);
    }
  }

  function search(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void runSearch(employeeId);
  }

  // Deep link from a passport QR scan (?emp=…): run the lookup ourselves so the profile
  // opens immediately — the scanner never has to type the Employee ID.
  const autoRanRef = useRef(false);
  useEffect(() => {
    if (autoRanRef.current || !autoEmployeeId || lookupUnavailable) return;
    autoRanRef.current = true;
    setEmployeeId(autoEmployeeId.trim().toUpperCase());
    void runSearch(autoEmployeeId);
    // runSearch identity changes with `searching`, but this effect must run exactly once.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoEmployeeId, lookupUnavailable]);

  useEffect(() => {
    if (result) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [result, onClose]);

  if (result) {
    // Company-wide lookups can match an employee from another site; resolve their actual site.
    const employeeSite = sites?.find((candidate) => candidate.id === result.siteId)
      ?? (site?.id === result.siteId ? site : null);
    return <EmployeePassport
      employee={result}
      site={employeeSite}
      companyName={companyName}
      onBack={() => { setResult(null); setEmployeeId(''); setMessage(null); }}
      onClose={onClose}
      history={history}
      privateAccess={privateAccess}
      profileQrPath={profileQrPath}
    />;
  }

  return <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="profile-search-title" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="modal profile-search-modal">
    <div className="modal-header"><div><span className="eyebrow">{T('EMPLOYEE DIRECTORY')}</span><h2 id="profile-search-title">{T('Search Employee Profile')}</h2></div><button className="close-button" type="button" onClick={onClose} aria-label={T('Close employee profile')}><X /></button></div>
    <form className="profile-search-form" onSubmit={search}><label htmlFor="profile-search-code" className="field-label">{T('Employee ID')}</label><div className="search-box"><Search size={17} /><input id="profile-search-code" value={employeeId} onChange={(event) => { setEmployeeId(event.target.value.toUpperCase()); setMessage(null); }} placeholder={lookupUnavailable ? T('Employee master not connected') : T('Enter Employee ID')} autoComplete="off" required /></div><button type="submit" className="primary-button full-button" disabled={searching || lookupUnavailable}>{T(searching ? 'Searching…' : lookupUnavailable ? 'Search unavailable' : 'Search Employees')}</button></form>
    {message && <div className="inline-notice warning" role="status">{T(message.key, message.params)}</div>}
    {directoryMode && <div className={`directory-source ${directoryMode === 'unavailable' ? 'is-unavailable' : ''}`} role="status">
      <span className="directory-source-dot" aria-hidden="true" />
      <b>{SOURCE_LABEL[directoryMode]}</b>
      {directoryMode !== 'unavailable' && <span>· {employeeCount.toLocaleString('en-IN')} active employees</span>}
      {directoryMode === 'unavailable' && <span>· {directoryReason ? UNAVAILABLE_HINT[directoryReason] : 'no employee source answered'}</span>}
    </div>}
  </div></div>;
}
