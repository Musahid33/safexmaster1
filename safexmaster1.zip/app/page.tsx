'use client';

import {
  AlertTriangle, ArrowLeft, Bell, BookOpen, CalendarCheck, CalendarDays, Check, ChevronDown, ChevronRight, Clock3,
  Eye, FileText, FolderOpen, Globe2, GraduationCap, Home, Lightbulb, LockKeyhole, MapPin,
  Monitor, Mic, Moon, MoreHorizontal, Palette, PhoneCall, Shield, ShieldAlert,
  Smartphone, Sun, UserRound, X, Zap, MessageSquare
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode, type TouchEvent as ReactTouchEvent } from 'react';
import { forSelectedSite, initialSiteId, siteStorageKey } from '@/lib/site-selection';
import { DEMO_FEED, DEMO_RECOGNITIONS, DEMO_REPORTS, DEMO_SITES } from '@/lib/demo-fixture';
import { portalName } from '@/lib/portal-branding';
import { pendingReports, queueReport, syncQueuedReports, type ReportSender } from '@/lib/offline-report-queue';
import { SAFETY_ALERTS, SAFETY_ALERT_FILTERS, type SafetyAlert, type SafetyAlertCategory } from '@/lib/safety-alerts';
import { APP_FEATURES, brandingFor } from '@/lib/app-config';
import { telHref } from '@/lib/emergency';
import { LANGUAGES, LANGUAGE_LOCALE } from '@/lib/i18n';
import { appendResourceQuery } from '@/lib/safe-url';
import LanguageStrip from './components/LanguageStrip';
import { useI18n } from './components/I18nProvider';
import ReportWorkflow, { type ReportSubmission } from './components/ReportWorkflow';
import TrainingPortal from './components/TrainingPortal';
import ProfileSearchDialog from './components/ProfileSearchDialog';
import { DocumentVaultGrid, type VaultCategoryId, type VaultDocument } from './components/DocumentVault';
import { VaultShelf } from './components/VaultShelf';
import LoggedReports from './components/LoggedReports';
import RewardCarousel, { type RecognitionGalleryItem } from './components/RewardCarousel';
import { FeedArchivePage, HomeFeedDetailDialog } from './components/HomeFeedViews';
import { useSafexBootstrap } from './components/useSafexBootstrap';
import { AboutAppPage, AccountManagementPage, CompanyAboutPage, InstallAppPage, MoreInfoDialog, MoreMenuPage, type MoreInfoKind } from './components/MorePages';
import { APP_TIME_ZONE, formatHomeFeedDate, formatHomeFeedTime, type HomeFeedItem } from '@/lib/home-content';
import type { Palette as PaletteName, ReportType, Site, ThemeMode } from '@/lib/types';

// No server is connected in the UI preview. A future sender must use the queue ID
// as an idempotency key and acknowledge only after the tenant-scoped report is saved.
const REPORT_SENDER: ReportSender | null = null;

type PageKey = 'home' | 'reports' | 'alerts' | 'events' | 'circulars' | 'updates' | 'training' | 'more' | 'appearance' | 'install' | 'library' | 'company' | 'account' | 'aboutApp';
type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> };
type UiMessage = { key: string; params?: Record<string, string | number>; report?: { type: ReportType; category: string | null } };

type HomeReportTile = {
  id: string;
  reportType?: ReportType;
  opensConcernChooser?: boolean;
  opensFeedbackChooser?: boolean;
  icon: typeof Zap;
  tone: string;
  labelKey?: string;
  titleEn?: string;
  titleHi?: string;
  descEn: string;
  descHi: string;
};

const HOME_REPORT_TILES: HomeReportTile[] = [
  { id: 'near-miss', reportType: 'Near Miss', icon: Zap, tone: 'amber', labelKey: 'nearMiss', descEn: 'A close call worth reporting', descHi: 'बाल-बाल बचे' },
  { id: 'hazard', reportType: 'Hazard', icon: AlertTriangle, tone: 'red', labelKey: 'hazard', descEn: 'Report a hazard', descHi: 'Hazard बताएँ' },
  { id: 'observation', reportType: 'Safety Observation', icon: Eye, tone: 'blue', labelKey: 'safetyObservation', titleHi: 'निरीक्षण', descEn: 'Unsafe condition / unsafe act', descHi: 'UC / UA' },
  { id: 'feedback-suggestion', opensFeedbackChooser: true, icon: MessageSquare, tone: 'teal', titleEn: 'Feedback & Suggestion', descEn: 'Share your experience or ideas', descHi: 'अनुभव या सुझाव साझा करें' },
  { id: 'concern', opensConcernChooser: true, icon: Shield, tone: 'purple', titleEn: 'Grievances & Speak Up', titleHi: 'शिकायत / खुलकर बोलें', descEn: 'Anonymous option available', descHi: 'गुमनाम विकल्प उपलब्ध है' },
];

// The direct picker follows the reference while reusing the home reporting actions.
const DIRECT_REPORT_TILES: HomeReportTile[] = [
  ...HOME_REPORT_TILES.slice(0, 3),
  { id: 'unsafe-condition', reportType: 'Unsafe Condition', icon: AlertTriangle, tone: 'amber', labelKey: 'uc', descEn: 'Report an unsafe condition at your work site', descHi: 'असुरक्षित स्थिति बताएँ' },
  { id: 'unsafe-act', reportType: 'Unsafe Act', icon: ShieldAlert, tone: 'red', labelKey: 'unsafeAct', descEn: 'Report an unsafe act or behaviour', descHi: 'असुरक्षित कार्य बताएँ' },
  ...HOME_REPORT_TILES.slice(3),
];

function getUpcomingEventStatus(value: string): 'Today' | 'Tomorrow' | 'Upcoming' {
  const eventDate = new Date(value);
  const now = new Date();
  const calendarDay = (date: Date) => {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: APP_TIME_ZONE, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
    const part = (type: Intl.DateTimeFormatPartTypes) => Number(parts.find((entry) => entry.type === type)?.value);
    return Date.UTC(part('year'), part('month') - 1, part('day'));
  };
  const daysAway = Math.round((calendarDay(eventDate) - calendarDay(now)) / 86_400_000);
  if (daysAway <= 0) return 'Today';
  if (daysAway === 1) return 'Tomorrow';
  return 'Upcoming';
}

export default function SafexHome() {
  const { language, setLanguage, T } = useI18n();
  // Tenant details are supplied by the public portal route when it is configured.
  const { ready: directoryReady, tenantId, companySlug, sites, directory, companyName, directoryMode, directoryReason, employeeCount } = useSafexBootstrap();
  // Derive the portal name only from the selected tenant's supplied company name.
  const brandCompanyName = (companyName ?? '').trim();
  const company = brandingFor(brandCompanyName);
  const appName = portalName(companyName);
  const locale = LANGUAGE_LOCALE[language];
  // TEMPORARY DEMO MODE: ?demo=1 in the URL (development builds only) runs the home
  // experience on lib/demo-fixture.ts sample data so site filtering, the View Reports
  // dropdown and the hero banner can be tested before the database connects. Removed
  // before production together with the fixture file.
  const [demoMode, setDemoMode] = useState(false);
  const [demoChecked, setDemoChecked] = useState(process.env.NODE_ENV !== 'development');
  const [languageMenuOpen, setLanguageMenuOpen] = useState(false);
  const [page, setPage] = useState<PageKey>('home');
  const [accountReturnPage, setAccountReturnPage] = useState<PageKey>('home');
  const [reportOrigin, setReportOrigin] = useState<'home' | 'picker'>('home');
  const [recognitions] = useState<RecognitionGalleryItem[] | null>(null);
  // Empty preview content for the vault and home feed.
  const [vaultDocuments] = useState<VaultDocument[]>([]);
  const [contentFeed] = useState<HomeFeedItem[]>([]);
  const displaySites = demoMode ? DEMO_SITES : sites;
  const displayFeed = demoMode ? DEMO_FEED : contentFeed;
  const displayRecognitions = demoMode ? DEMO_RECOGNITIONS : recognitions;
  const [siteId, setSiteId] = useState('');
  const [siteReady, setSiteReady] = useState(false);
  const [siteDialog, setSiteDialog] = useState(false);
  const [siteDraft, setSiteDraft] = useState('');
  const [siteReturnPage, setSiteReturnPage] = useState<PageKey>('home');
  const [lifeRuleOpen, setLifeRuleOpen] = useState(false);
  const [lifeRuleSite, setLifeRuleSite] = useState<Site | null>(null);
  const [themeMode, setThemeMode] = useState<ThemeMode>('system');
  const [palette, setPalette] = useState<PaletteName>('safex');
  const [reportType, setReportType] = useState<ReportType | null>(null);
  const [pendingReportCount, setPendingReportCount] = useState<number | null>(null);
  const [reportPickerOpen, setReportPickerOpen] = useState(false);
  const [quickConcernChooserOpen, setQuickConcernChooserOpen] = useState(false);
  const [feedbackChooserOpen, setFeedbackChooserOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [safetyAlertsOpen, setSafetyAlertsOpen] = useState(false);
  const [safetyAlertFilter, setSafetyAlertFilter] = useState<'All' | SafetyAlertCategory>('All');
  /** Alerts published from the console. Falls back to the (empty) built-in list when offline. */
  const [publishedAlerts] = useState<SafetyAlert[]>(SAFETY_ALERTS);
  const [expandedSafetyAlertId, setExpandedSafetyAlertId] = useState<string | null>(null);
  const [sosOpen, setSosOpen] = useState(false);
  const [profileSearchOpen, setProfileSearchOpen] = useState(false);
  const [qrEmployeeId, setQrEmployeeId] = useState<string | null>(null);
  const [moreInfoKind, setMoreInfoKind] = useState<MoreInfoKind | null>(null);
  const [notificationPermission, setNotificationPermission] = useState('not requested');
  const [pushPrefs, setPushPrefs] = useState({ safety: true, notices: true, training: true, ownReports: true, allVendorSites: false, hideLockScreen: true });
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installMessage, setInstallMessage] = useState<UiMessage | null>(null);
  const [toast, setToast] = useState<UiMessage | null>(null);
  const [vaultCategoryId, setVaultCategoryId] = useState<VaultCategoryId | null>(null);

  /** A shelf opens as its own register screen inside the library page. */
  const openVaultShelf = useCallback((category: VaultCategoryId) => {
    setVaultCategoryId(category);
    setPage('library');
  }, []);
  const [feedDetail, setFeedDetail] = useState<HomeFeedItem | null>(null);
  const languageMenuRef = useRef<HTMLDivElement>(null);
  const safetyAlertsScrollRef = useRef<HTMLDivElement>(null);
  const safetyAlertsTouchStart = useRef<{ x: number; y: number } | null>(null);

  const currentSite = displaySites.find((site) => site.id === siteId) ?? null;
  // Events / Circulars / Notices follow the selected site. Items without a site tag are
  // company-wide and appear everywhere; tagged items show only for their site.
  const siteFeed = useMemo(
    () => displayFeed.filter((item) => !item.siteId || item.siteId === currentSite?.id),
    [displayFeed, currentSite?.id]
  );
  const nextUpcomingEvent = useMemo(() => siteFeed
    .filter((item) => item.type === 'Event' && new Date(item.date).getTime() >= Date.now())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0] ?? null, [siteFeed]);
  const filteredSafetyAlerts = useMemo(() => publishedAlerts
    .filter((alert) => safetyAlertFilter === 'All' || alert.category === safetyAlertFilter)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()), [publishedAlerts, safetyAlertFilter]);
  // The selected tenant/site supplies this number; never substitute another tenant’s contact.
  const sosNumber = currentSite?.sosNumber?.trim() || null;
  const sosDialHref = telHref(sosNumber);
  const isSingleSite = displaySites.length === 1;
  const selectedRules = currentSite?.lifeSavingRules ?? [];
  // Hero counters come from the tenant data source for the selected site only.
  const siteStats = currentSite?.stats ?? null;
  const statFormatter = useMemo(() => new Intl.NumberFormat(locale), [locale]);
  // Until the tenant database supplies stats, every counter shows zero instead of fake numbers.
  const formatStat = useCallback((value: number | null | undefined) => statFormatter.format(value ?? 0), [statFormatter]);
  const siteRecognitions = useMemo(() => displayRecognitions === null ? null : forSelectedSite(displayRecognitions, currentSite?.id), [displayRecognitions, currentSite?.id]);

  useEffect(() => {
    try {
      const savedMode = localStorage.getItem('safex-theme-mode') as ThemeMode | null;
      const savedPalette = localStorage.getItem('safex-palette') as PaletteName | null;
      const savedPush = localStorage.getItem('safex-push-preferences');
      if (savedMode && ['system', 'light', 'dark'].includes(savedMode)) setThemeMode(savedMode);
      if (savedPalette && ['safex', 'ocean', 'forest', 'contrast'].includes(savedPalette)) setPalette(savedPalette);
      if (savedPush) {
        const parsed = JSON.parse(savedPush) as Partial<typeof pushPrefs>;
        setPushPrefs((current) => ({ ...current, ...parsed }));
      }
      if ('Notification' in window) setNotificationPermission(Notification.permission);

    } catch {
      // Storage can be unavailable (private mode, locked-down device); defaults stand.
    }

    const handleInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const handleAppInstalled = () => setInstallMessage({ key: 'The app has been installed on this device.' });
    window.addEventListener('beforeinstallprompt', handleInstall);
    window.addEventListener('appinstalled', handleAppInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      if (new URLSearchParams(window.location.search).has('demo')) setDemoMode(true);
      setDemoChecked(true);
    }
  }, []);

  // A site choice is remembered on this device for this tenant, not shared across tenants.
  const lastTenantRef = useRef<string | undefined>(undefined);
  useEffect(() => {
    if (!directoryReady || !demoChecked) return;
    const scopeKey = `${tenantId ?? ''}|${demoMode ? 'demo' : 'live'}`;
    if (siteReady && lastTenantRef.current === scopeKey) return;
    lastTenantRef.current = scopeKey;
    let savedId: string | null = null;
    try { if (tenantId) savedId = localStorage.getItem(siteStorageKey(tenantId)); }
    catch { /* Without storage, a multi-site tenant will need to choose again. */ }
    const selectedSite = initialSiteId(savedId, displaySites);
    if (selectedSite) {
      setSiteId(selectedSite);
      setSiteDraft(selectedSite);
      setSiteDialog(false);
      if (displaySites.length === 1 && tenantId) {
        try { localStorage.setItem(siteStorageKey(tenantId), selectedSite); } catch { /* The selection still applies for this visit. */ }
      }
    } else {
      setSiteId('');
      setSiteDraft('');
      setSiteDialog(true);
    }
    setSiteReady(true);
  }, [directoryReady, demoChecked, siteReady, displaySites, tenantId, demoMode]);

  useEffect(() => {
    if (!tenantId) { setPendingReportCount(null); return; }
    let active = true;
    let running = false;
    async function refreshQueue() {
      if (running) return;
      running = true;
      try {
        if (REPORT_SENDER && navigator.onLine) await syncQueuedReports(tenantId!, REPORT_SENDER);
        const entries = await pendingReports(tenantId!);
        if (active) setPendingReportCount(entries.length);
      } catch { if (active) setPendingReportCount(null); }
      finally { running = false; }
    }
    void refreshQueue();
    window.addEventListener('online', refreshQueue);
    return () => { active = false; window.removeEventListener('online', refreshQueue); };
  }, [tenantId]);

  useEffect(() => { document.title = appName; }, [appName]);

  // A passport QR scan lands on the home URL as ?emp=<Employee ID>: open the profile
  // search and let the dialog run the lookup, so the profile opens without any typing.
  useEffect(() => {
    if (!directoryReady || qrEmployeeId) return;
    const id = new URLSearchParams(window.location.search).get('emp')?.toUpperCase();
    if (!id) return;
    setQrEmployeeId(id);
    setProfileSearchOpen(true);
  }, [directoryReady, qrEmployeeId]);

  useEffect(() => {
    document.documentElement.dataset.mode = themeMode;
    document.documentElement.dataset.palette = palette;
    try {
      localStorage.setItem('safex-theme-mode', themeMode);
      localStorage.setItem('safex-palette', palette);
    } catch { /* Preferences remain available for the current session if storage is blocked. */ }
  }, [themeMode, palette]);

  useEffect(() => {
    if (!languageMenuOpen) return;
    const closeOnOutsidePointer = (event: PointerEvent) => {
      if (!languageMenuRef.current?.contains(event.target as Node)) setLanguageMenuOpen(false);
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setLanguageMenuOpen(false);
    };
    document.addEventListener('pointerdown', closeOnOutsidePointer);
    document.addEventListener('keydown', closeOnEscape);
    return () => {
      document.removeEventListener('pointerdown', closeOnOutsidePointer);
      document.removeEventListener('keydown', closeOnEscape);
    };
  }, [languageMenuOpen]);

  useEffect(() => {
    if (!safetyAlertsOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSafetyAlertsOpen(false);
    };
    document.addEventListener('keydown', closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', closeOnEscape);
    };
  }, [safetyAlertsOpen]);

  useEffect(() => {
    const anyDialogOpen = lifeRuleOpen || quickConcernChooserOpen || reportPickerOpen || notificationsOpen || sosOpen || (siteReady && siteDialog && (Boolean(currentSite) || displaySites.length === 0));
    if (!anyDialogOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      if (sosOpen) setSosOpen(false);
      else if (notificationsOpen) setNotificationsOpen(false);
      else if (lifeRuleOpen) setLifeRuleOpen(false);
      else if (quickConcernChooserOpen) setQuickConcernChooserOpen(false);
      else if (reportPickerOpen) setReportPickerOpen(false);
      else if (siteReady && siteDialog && (Boolean(currentSite) || displaySites.length === 0)) setSiteDialog(false);
    };
    document.addEventListener('keydown', closeOnEscape);
    return () => document.removeEventListener('keydown', closeOnEscape);
  }, [lifeRuleOpen, quickConcernChooserOpen, reportPickerOpen, notificationsOpen, sosOpen, siteReady, siteDialog, currentSite, displaySites.length]);

  useEffect(() => {
    try { localStorage.setItem('safex-push-preferences', JSON.stringify(pushPrefs)); } catch { /* session-only preference */ }
  }, [pushPrefs]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3800);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function openSitePicker(returnTo: PageKey = page) {
    setSiteReturnPage(returnTo);
    setSiteDraft(siteId || '');
    setSiteDialog(true);
  }

  function chooseSite(id: string) {
    const valid = displaySites.find((site) => site.id === id);
    if (!valid) return;
    setSiteId(valid.id);
    setSiteDraft(valid.id);
    try { if (tenantId) localStorage.setItem(siteStorageKey(tenantId), valid.id); } catch { /* Choice lasts only until this page is closed. */ }
    setLifeRuleOpen(false);
    setLifeRuleSite(null);
    setSosOpen(false);
    setSiteDialog(false);
    setPage(siteReturnPage);
    setToast({ key: 'Selected site {site}.', params: { site: valid.name } });
  }

  function openLifeRuleForSite(site: Site) {
    setLifeRuleSite(site);
    setLifeRuleOpen(true);
  }



  function openReport(type: ReportType) {
    if (!currentSite) {
      openSitePicker('home');
      return;
    }
    setReportType(type);
  }

  function reportTileTitle(item: HomeReportTile) {
    return item.opensFeedbackChooser ? `${T('feedback')} & ${T('suggestion')}` : item.opensConcernChooser ? (language === 'en' ? 'Grievances & Speak Up' : `${T('grievance')} & ${T('speakUp')}`) : item.labelKey ? T(item.labelKey) : T(item.titleEn ?? '');
  }

  function selectReportTile(item: HomeReportTile) {
    setReportOrigin(reportPickerOpen ? 'picker' : 'home');
    setReportPickerOpen(false);
    if (item.opensFeedbackChooser) setFeedbackChooserOpen(true);
    else if (item.opensConcernChooser) setQuickConcernChooserOpen(true);
    else if (item.reportType) openReport(item.reportType);
  }

  function backFromReport() {
    const type = reportType;
    setReportType(null);
    if (type === 'Feedback' || type === 'Suggestion') setFeedbackChooserOpen(true);
    else if (type === 'Grievance' || type === 'Speak Up') setQuickConcernChooserOpen(true);
    else if (reportOrigin === 'picker') setReportPickerOpen(true);
  }

  function backFromChooser(kind: 'feedback' | 'concern') {
    if (kind === 'feedback') setFeedbackChooserOpen(false);
    else setQuickConcernChooserOpen(false);
    if (reportOrigin === 'picker') setReportPickerOpen(true);
  }

  function renderReportTiles() {
    return HOME_REPORT_TILES.map((item) => {
      const Icon = item.icon;
      const title = reportTileTitle(item);
      return <button key={item.id} type="button" className={`report-tile ${item.opensConcernChooser ? 'report-tile-concern' : ''}`} aria-label={title} aria-haspopup={item.opensFeedbackChooser || item.opensConcernChooser ? 'dialog' : undefined} onClick={() => selectReportTile(item)}>
        <span className={`tile-icon ${item.tone}`}><Icon size={26} strokeWidth={2.1} aria-hidden="true" /></span>
        <span className="tile-copy"><b>{title}</b><small>{T(item.descEn)}</small></span>
      </button>;
    });
  }

  function openSafetyAlerts() {
    setSafetyAlertFilter('All');
    setExpandedSafetyAlertId(null);
    setSafetyAlertsOpen(true);
  }

  function closeSafetyAlerts() {
    setSafetyAlertsOpen(false);
    setExpandedSafetyAlertId(null);
  }

  function handleSafetyAlertsBack() {
    if (expandedSafetyAlertId) setExpandedSafetyAlertId(null);
    else closeSafetyAlerts();
  }

  function handleSafetyAlertsTouchStart(event: ReactTouchEvent<HTMLDivElement>) {
    const touch = event.touches[0];
    if (touch) safetyAlertsTouchStart.current = { x: touch.clientX, y: touch.clientY };
  }

  function handleSafetyAlertsTouchEnd(event: ReactTouchEvent<HTMLDivElement>) {
    const start = safetyAlertsTouchStart.current;
    const touch = event.changedTouches[0];
    safetyAlertsTouchStart.current = null;
    if (!start || !touch) return;
    const deltaY = touch.clientY - start.y;
    const deltaX = touch.clientX - start.x;
    const scrollIsAtTop = (safetyAlertsScrollRef.current?.scrollTop ?? 0) <= 0;
    if (deltaY > 110 && Math.abs(deltaX) < 85 && scrollIsAtTop) closeSafetyAlerts();
  }

  async function submitReport(data: ReportSubmission) {
    if (!tenantId || !currentSite) throw new Error('Reports cannot be saved until company and site data are connected.');
    await queueReport(tenantId, currentSite.id, data);
    setReportType(null);
    setToast({ key: 'Saved on this device. Not sent to the server.' });
    // Once a server sender is configured, retry when online; records remain until acknowledged.
    if (REPORT_SENDER && navigator.onLine) await syncQueuedReports(tenantId, REPORT_SENDER);
    try { setPendingReportCount((await pendingReports(tenantId)).length); }
    catch { setPendingReportCount(null); }
  }

  async function requestPushPermission() {
    if (!('Notification' in window)) {
      setNotificationPermission('unsupported');
      setToast({ key: 'This browser does not support web notifications.' });
      return;
    }
    try {
      const result = await Notification.requestPermission();
      setNotificationPermission(result);
      if (result === 'granted') setToast({ key: 'Device permission granted. Server push delivery still needs VAPID/backend setup.' });
      else setToast({ key: 'Notifications remain off until device permission is granted.' });
    } catch {
      setToast({ key: 'Notification permission could not be requested in this browser.' });
    }
  }

  async function installApp() {
    if (installPrompt) {
      await installPrompt.prompt();
      const result = await installPrompt.userChoice;
      setInstallMessage({ key: result.outcome === 'accepted' ? 'Install accepted. Follow your device prompt to finish.' : 'Install was dismissed; you can try again later.' });
      setInstallPrompt(null);
      return;
    }
    setInstallMessage({ key: 'No one-tap install prompt is available here. Use the browser menu → Install app / Add to Home Screen. On iPhone, use Share → Add to Home Screen.' });
  }

  function setPref(key: keyof typeof pushPrefs) {
    setPushPrefs((prefs) => ({ ...prefs, [key]: !prefs[key] }));
  }

  const nextEventDate = nextUpcomingEvent ? new Date(nextUpcomingEvent.date) : null;
  const nextEventDay = nextEventDate ? new Intl.DateTimeFormat(locale, { timeZone: APP_TIME_ZONE, day: '2-digit' }).format(nextEventDate) : '';
  const nextEventMonth = nextEventDate ? new Intl.DateTimeFormat(locale, { timeZone: APP_TIME_ZONE, month: 'short' }).format(nextEventDate).replace('.', '').toLocaleUpperCase(locale) : '';
  const nextEventStatus = nextUpcomingEvent ? getUpcomingEventStatus(nextUpcomingEvent.date) : null;

  const siteSelectionDialog = siteReady && siteDialog ? (
    <div className="overlay site-overlay" role="dialog" aria-modal="true" aria-labelledby="site-title"><div className="modal site-modal">{(currentSite || displaySites.length === 0) && <div className="site-modal-actions"><button className="close-button" type="button" onClick={() => setSiteDialog(false)} aria-label={T('Close site selection')}><X /></button></div>}<LanguageStrip language={language} onChange={setLanguage} className="site-language-strip" /><span className="eyebrow">{T('SITE SELECTION')}</span><h2 id="site-title">{T('sitePrompt')}</h2><p>{T('Select your work site. Your choice will be remembered on this device and can be changed later.')}</p>{displaySites.length === 0
              ? <div className="inline-notice warning">{T('No sites are connected in this UI preview.')}</div>
              : <><label className="field-label" htmlFor="site-select">{T('selectSite')}</label><select id="site-select" className="form-control" value={siteDraft} onChange={(e) => setSiteDraft(e.target.value)}><option value="" disabled>{T('Select a site')}</option>{displaySites.map((site) => <option key={site.id} value={site.id}>{site.name} · {site.region}</option>)}</select><button className="primary-button full-button" type="button" disabled={!siteDraft} onClick={() => chooseSite(siteDraft)}>{T('continue')} <ChevronRight size={17} /></button></>}</div></div>
  ) : null;

  return (
    <div className="safex-app">
      <div role="status" style={{ background: "#fff4d6", color: "#513900", textAlign: "center", padding: "8px 12px", fontSize: 13 }}>UI preview only · No live data or server report submissions{pendingReportCount ? ` · ${pendingReportCount} report(s) saved on this device, not sent` : ''}</div>
      {demoMode && <div role="status" className="demo-ribbon">DEMO MODE · sample sites, stats, events &amp; reports (temporary — removed before production)</div>}
      <div className="site-header-shell">
        <header className="topbar">
          <div className="topbar-inner">
            <div className="topbar-brand-row">
              <button className="brand-button" onClick={() => setPage('home')} aria-label={T('Home')}>
                <span className="topbar-company-logo"><img src="/icon-192.png" alt="Safex" /></span>
                <span className="topbar-company-name">{appName}</span>
              </button>
            </div>

            <hr className="topbar-divider" />

            <div className="header-toolbar">
              {isSingleSite ? (
                <div className="header-site-switch header-site-switch-static">
                  <MapPin size={16} aria-hidden="true" />
                  <span className="header-site-name">{currentSite?.name ?? T('Site')}</span>
                </div>
              ) : (
                <button
                  type="button"
                  className="header-site-switch"
                  onClick={() => openSitePicker(page)}
                  aria-label={currentSite ? T('Selected site {site}. Change site', { site: currentSite.name }) : T('Choose site')}
                >
                  <MapPin size={16} aria-hidden="true" />
                  <span className="header-site-name">{currentSite?.name ?? T('Choose site')}</span>
                  {currentSite && <span className="header-change-site">{T('changeSite')}</span>}
                  <ChevronDown size={14} className="header-site-chevron" aria-hidden="true" />
                </button>
              )}

              <div className="header-actions">
                <div className={`header-language ${languageMenuOpen ? 'open' : ''}`} ref={languageMenuRef}>
                  <button
                    id="safex-language-button"
                    type="button"
                    className="header-ui-button header-language-toggle"
                    aria-label={T('Choose language. Current selection: {language}', { language: LANGUAGES.find((item) => item.id === language)?.native ?? 'English' })}
                    title={T('Choose language')}
                    aria-haspopup="listbox"
                    aria-expanded={languageMenuOpen}
                    aria-controls="safex-language-menu"
                    onClick={() => setLanguageMenuOpen((open) => !open)}
                  >
                    <Globe2 size={20} aria-hidden="true" />
                    <span className="header-language-label-compact" lang={language}>{LANGUAGES.find((item) => item.id === language)?.native ?? 'English'}</span>
                    <span className="header-language-label-wide">{T('Choose language')}</span>
                    <ChevronDown size={14} className="header-language-chevron" aria-hidden="true" />
                  </button>
                  {languageMenuOpen && <ul id="safex-language-menu" className="header-language-menu" role="listbox" aria-label={T('Choose language')}>
                    {LANGUAGES.map((item) => <li key={item.id}>
                      <button
                        type="button"
                        role="option"
                        className="header-language-option"
                        aria-selected={language === item.id}
                        onClick={() => { setLanguage(item.id); setLanguageMenuOpen(false); }}
                      >{item.native}</button>
                    </li>)}
                  </ul>}
                </div>
                {APP_FEATURES.pushNotifications && <button className="header-ui-button header-notification-button" onClick={() => setNotificationsOpen(true)} aria-label={T('Notification settings')}>
                  <Bell size={19} aria-hidden="true" />
                </button>}
                <button className="header-ui-button header-sos-button" onClick={() => setSosOpen(true)} aria-label={T('SOS emergency contact')}>SOS</button>
                <button className="header-ui-button header-account-button" onClick={() => { if (page !== 'account') setAccountReturnPage(page); setPage('account'); }} aria-label={T('Account')}><UserRound size={19} aria-hidden="true" /></button>
              </div>
            </div>
          </div>
        </header>
      </div>
      <main className="main-content">
        {(page === 'reports' || page === 'training' || page === 'more' || (page === 'library' && !vaultCategoryId) || page === 'appearance') && <button type="button" className="more-page-back section-page-back" onClick={() => setPage(page === 'appearance' ? 'more' : 'home')}><ArrowLeft size={16} aria-hidden="true" /> {T('Back')}</button>}

        {page === 'home' && <>
          <section className="hero-strip hero-stats-banner" aria-labelledby="hero-days-heading">
            <span className="eyebrow hero-eyebrow">{appName}</span>
            <div className="hero-days-row">
              <span className="hero-days-icon" aria-hidden="true"><CalendarCheck size={34} strokeWidth={2.1} /></span>
              <h1 className="hero-days-heading" id="hero-days-heading">
                <b className="hero-days-number">{formatStat(siteStats?.daysWithoutInjury)}</b>
                <span className="hero-days-label"> {T('Days Without Injury')}</span>
              </h1>
            </div>
            <div className="hero-metrics" aria-label={T('Site safety counters')}>
              <div className="hero-metric">
                <span className="hero-metric-icon training" aria-hidden="true"><GraduationCap size={22} /></span>
                <span className="hero-metric-copy"><span className="hero-metric-label">{T('training')}</span><b className="hero-metric-value">{formatStat(siteStats?.trainingCount)}</b></span>
              </div>
              <div className="hero-metric">
                <span className="hero-metric-icon near-miss" aria-hidden="true"><AlertTriangle size={22} /></span>
                <span className="hero-metric-copy"><span className="hero-metric-label">{T('nearMiss')}</span><b className="hero-metric-value">{formatStat(siteStats?.nearMissCount)}</b></span>
              </div>
              <div className="hero-metric">
                <span className="hero-metric-icon observation" aria-hidden="true"><Eye size={22} /></span>
                <span className="hero-metric-copy"><span className="hero-metric-label">{T('safetyObservation')}</span><b className="hero-metric-value">{formatStat(siteStats?.safetyObservationCount)}</b></span>
              </div>
            </div>
            <p className="hero-tagline">{T('One platform to report, learn and improve workplace safety.')}</p>
          </section>
          <section className="section-block">
            <div className="section-heading"><div><span className="eyebrow">{T('TAKE ACTION')}</span><h2>{T('Report a safety concern')}</h2></div><span className="section-note">{T('No login needed to submit')}</span></div>
            <div className="report-grid">
              {renderReportTiles()}
            </div>
          </section>
          <section className="section-block quick-section">
            <div className="section-heading"><div><span className="eyebrow">{T('QUICK ACCESS')}</span><h2>{T('Safety Resources')}</h2></div></div>
            <div className="home-feature-list">
              <button className="home-feature-row reports-feature" onClick={() => setPage('reports')}>
                <span className="home-feature-icon"><FileText size={22} /></span>
                <span className="home-feature-copy"><b>{T('viewReports')}</b><small>{T('Track Open / Closed status')}</small></span>
                <ChevronRight size={20} />
              </button>
              <button className="home-feature-row life-saving-row" type="button" onClick={() => currentSite && openLifeRuleForSite(currentSite)} disabled={!currentSite} aria-haspopup="dialog">
                <span className="home-feature-icon life-saving-row-icon"><ShieldAlert size={22} /></span>
                <span className="home-feature-copy"><b>{T('LIFE SAVING RULE')}</b><small>{currentSite?.name ?? T('Select site')} · {selectedRules.length ? T('{count} rules', { count: selectedRules.length }) : T('Rules not configured')}</small></span>
                <ChevronRight size={20} />
              </button>
              {APP_FEATURES.trainingManagement && <button className="home-feature-row" onClick={() => setPage('training')}>
                <span className="home-feature-icon"><Smartphone size={22} /></span>
                <span className="home-feature-copy"><b>{T('Training Management')}</b><small>{T('Modules, videos and progress')}</small></span>
                <ChevronRight size={20} />
              </button>}
              <button className="home-feature-row safety-alerts-feature" type="button" onClick={openSafetyAlerts} aria-haspopup="dialog">
                <span className="home-feature-icon safety-alerts-icon"><Bell size={22} /></span>
                <span className="home-feature-copy"><b>{T('Safety Alerts')}</b><small>{T('Incident alerts, controls & lessons learned')}</small></span>
                <ChevronRight size={20} />
              </button>
              {(APP_FEATURES.library || APP_FEATURES.circulars) && <button className="home-feature-row" onClick={() => setPage('updates')}>
                <span className="home-feature-icon"><FileText size={22} /></span>
                <span className="home-feature-copy"><b>{T(APP_FEATURES.library && !APP_FEATURES.circulars ? 'Safety Library' : 'Circulars & Notices')}</b><small>{T('Browse all circulars and notices')}</small></span>
              </button>}
              <section className="upcoming-events-module" aria-labelledby="upcoming-events-heading">
                <div className="upcoming-events-header">
                  <div className="upcoming-events-title"><span className="upcoming-events-icon"><CalendarDays size={22} aria-hidden="true" /></span><h3 id="upcoming-events-heading">{T('Upcoming Events')}</h3></div>
                  <button type="button" className="upcoming-events-view-all" onClick={() => setPage('events')} >{T('View All')} <ChevronRight size={17} aria-hidden="true" /></button>
                </div>
                {nextUpcomingEvent ? <button type="button" className="upcoming-event-summary" onClick={() => setFeedDetail(nextUpcomingEvent)} aria-label={T('Open event details: {title}, {date} {month}, {time}, {location}', { title: nextUpcomingEvent.title, date: nextEventDay, month: nextEventMonth, time: formatHomeFeedTime(nextUpcomingEvent.date, locale), location: nextUpcomingEvent.location ?? currentSite?.name ?? T('location to be announced') })}>
                  <span className="upcoming-event-date-badge"><b>{nextEventDay}</b><small>{nextEventMonth}</small></span>
                  <span className="upcoming-event-copy">
                    <span className="upcoming-event-title-row"><b>{nextUpcomingEvent.title}</b><span className={`upcoming-event-status ${nextEventStatus?.toLowerCase()}`}>{nextEventStatus ? T(nextEventStatus) : null}</span></span>
                    <span className="upcoming-event-meta"><span><Clock3 size={14} aria-hidden="true" />{formatHomeFeedTime(nextUpcomingEvent.date, locale)}</span><span className="upcoming-event-separator">•</span><span><MapPin size={14} aria-hidden="true" />{nextUpcomingEvent.location ?? currentSite?.name ?? T('Location to be announced')}</span></span>
                  </span>
                  <ChevronRight size={20} className="upcoming-event-arrow" aria-hidden="true" />
                </button> : <div className="upcoming-event-empty">{T('No upcoming events are scheduled for this site.')}</div>}
              </section>
            </div>
          </section>
          {APP_FEATURES.library && <section className="section-block document-vault-section">
            <div className="section-heading vault-section-heading"><div className="vault-section-title"><span className="vault-title-icon"><FolderOpen size={23} /></span><div className="vault-section-heading-copy"><h2>{T('Document Vault / Library')}</h2></div></div></div>
            <DocumentVaultGrid onSelect={openVaultShelf} documents={vaultDocuments} />
            <p className="home-demo-caption">{T('Site document categories. Only files published by the safety team are listed.')}</p>
          </section>}
          {APP_FEATURES.rewardWall && <section className="section-block reward-wall-section">
            <div className="section-heading"><div><span className="eyebrow">{T('RECOGNITION')}</span><h2 className="rewards-gallery-title"><span aria-hidden="true">🏆</span> {T('Rewards & Recognition Gallery')}</h2></div></div>
            <RewardCarousel items={siteRecognitions} siteSelected={Boolean(currentSite)} />
          </section>}
        </>}

        {page === 'reports' && <section className="page-panel">
          <div className="page-heading"><div><span className="eyebrow">{currentSite?.name ?? T('SITE')}</span><h1>{T('reportsTitle')}</h1></div>{!isSingleSite && <button type="button" className="secondary-button" onClick={() => openSitePicker('reports')}>{T('changeSite')}</button>}</div>
          <LoggedReports sites={displaySites} selectedSiteId={siteId} demoReports={demoMode ? DEMO_REPORTS : undefined} />
        </section>}

        {page === 'alerts' && <FeedArchivePage kind="notices" siteName={currentSite?.name ?? T('Selected site')} items={siteFeed} onOpenItem={setFeedDetail} onBack={() => setPage('home')} />}
        {page === 'events' && <FeedArchivePage kind="events" siteName={currentSite?.name ?? T('Selected site')} items={siteFeed} onOpenItem={setFeedDetail} onBack={() => setPage('home')} />}
        {page === 'circulars' && <FeedArchivePage kind="circulars" siteName={currentSite?.name ?? T('Selected site')} items={siteFeed} onOpenItem={setFeedDetail} onBack={() => setPage('home')} />}
        {page === 'updates' && <FeedArchivePage kind="updates" siteName={currentSite?.name ?? T('Selected site')} items={siteFeed} onOpenItem={setFeedDetail} onBack={() => setPage('home')} />}

        {page === 'training' && <TrainingPortal site={currentSite} />}

        {page === 'library' && (vaultCategoryId
          ? <VaultShelf
            categoryId={vaultCategoryId}
            siteName={currentSite?.name ?? T('Selected site')}
            documents={vaultDocuments}
            onBack={() => setVaultCategoryId(null)}
          />
          : <section className="page-panel document-vault-page">
            <div className="page-heading"><div><span className="eyebrow">{T('DOCUMENTS')} · {currentSite?.name ?? T('SELECTED SITE')}</span><h1>{T('Document Vault / Library')}</h1><p>{T('Browse site safety procedures, risk assessments, compliance indexes, policies and meeting minutes.')}</p></div><FolderOpen size={28} /></div>
            <DocumentVaultGrid onSelect={openVaultShelf} documents={vaultDocuments} />
          </section>)}

        {page === 'more' && <MoreMenuPage
          title={T('more')}
          companyName={brandCompanyName}
          onInstall={() => setPage('install')}
          onCompanyAbout={() => setPage('company')}
          onSearchEmployee={() => setProfileSearchOpen(true)}
          onAccount={() => { setAccountReturnPage('more'); setPage('account'); }}
          onAppearance={() => setPage('appearance')}
          onPrivacy={() => setMoreInfoKind('privacy')}
        />}

        {page === 'appearance' && <section className="page-panel narrow-panel"><div className="page-heading"><div><span className="eyebrow">{T('MORE · SETTINGS')}</span><h1>{T('appearance')}</h1><p>{T('Choose how the whole app looks on this device.')}</p></div><Palette size={28} /></div>
          <div className="settings-card"><h2>{T('Appearance mode')}</h2><div className="choice-row">{(['light', 'dark', 'system'] as ThemeMode[]).map((mode) => <button key={mode} className={`choice-chip ${themeMode === mode ? 'active' : ''}`} onClick={() => setThemeMode(mode)}>{mode === 'system' ? <Monitor size={16} /> : mode === 'light' ? <Sun size={16} /> : <Moon size={16} />}<span>{T(mode === 'system' ? 'System Default' : mode === 'light' ? 'Light Mode' : 'Dark Mode')}</span></button>)}</div></div>
          <div className="settings-card"><h2>{T('Colour theme')}</h2><p>{T('Colours apply to the header, home, report forms, cards and navigation.')}</p><div className="palette-grid">{([
            ['safex', 'Safex', '#0f2540', '#f5a623'], ['ocean', 'Ocean', '#123b5d', '#31b7c7'], ['forest', 'Forest', '#164b3a', '#70b77e'], ['contrast', 'High contrast', '#101820', '#ffd400']
          ] as [PaletteName, string, string, string][]).map(([id, name, primary, accent]) => <button key={id} className={`palette-choice ${palette === id ? 'selected' : ''}`} onClick={() => setPalette(id)}><span className="swatch-pair"><i style={{ background: primary }} /><i style={{ background: accent }} /></span><b>{T(name)}</b>{palette === id && <Check size={15} />}</button>)}</div></div>
          <div className="preview-card"><div className="preview-header"><span className="preview-logo">S</span><b>{appName} · {currentSite?.name ?? T('Site')}</b><span className="preview-sos">SOS</span></div><div className="preview-body"><span>{T('Home')}</span><span>{T('Report')}</span><span>{T('Safety Alerts')}</span></div></div>
        </section>}

        {page === 'install' && <InstallAppPage company={company} canInstall={Boolean(installPrompt)} installMessage={installMessage} onInstall={installApp} onBack={() => setPage('more')} />}

        {page === 'company' && <CompanyAboutPage profile={null} onBack={() => setPage('more')} />}
        {page === 'account' && <AccountManagementPage companySlug={companySlug} onBack={() => setPage(accountReturnPage)} />}
        {page === 'aboutApp' && <AboutAppPage company={company} onBack={() => setPage('more')} onOpenInfo={setMoreInfoKind} />}
      </main>

      {<nav className="bottom-nav" aria-label={T('Main navigation')}>
        <NavItem active={page === 'home'} icon={<Home />} label={T('home')} onClick={() => setPage('home')} />
        <NavItem active={safetyAlertsOpen} icon={<Bell />} label={T('Safety Alerts')} onClick={openSafetyAlerts} />
        <button className="nav-report" onClick={() => setReportPickerOpen(true)} aria-label={T('report')} aria-haspopup="dialog"><PlusIcon /><span>{T('report')}</span></button>
        {APP_FEATURES.trainingManagement && <NavItem active={page === 'training'} icon={<BookOpen />} label={T('training')} onClick={() => setPage('training')} />}
        <NavItem active={page === 'more' || page === 'appearance' || page === 'install' || page === 'library' || page === 'company' || page === 'account' || page === 'aboutApp'} icon={<MoreHorizontal />} label={T('more')} onClick={() => setPage('more')} />
      </nav>}

      {siteSelectionDialog}

      {lifeRuleOpen && lifeRuleSite && <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="life-rule-title"><div className="modal life-rule-modal"><div className="modal-header"><div><span className="eyebrow">{lifeRuleSite.name} · {T('LOCATION')}</span><h2 id="life-rule-title">{T('LIFE SAVING RULE')}</h2></div><button className="close-button" type="button" onClick={() => setLifeRuleOpen(false)} aria-label={T('Close Life Saving Rule')}><X /></button></div><div className="life-rule-site-banner"><span className="life-saving-icon"><ShieldAlert size={21} /></span><span><small>{T('SELECTED LOCATION')}</small><b>{lifeRuleSite.name}</b></span></div>{lifeRuleSite.lifeSavingRules?.length ? <ol className="life-rule-list">{lifeRuleSite.lifeSavingRules.map((rule, index) => <li key={`${index}-${rule.title}`}><span className="life-rule-number">{index + 1}</span><div><h3>{rule.title}</h3><p>{rule.text}</p></div></li>)}</ol> : <div className="inline-notice warning">{T('Life saving rules have not been configured for this site yet.')}</div>}<div className="life-rule-actions"><button className="primary-button" type="button" onClick={() => setLifeRuleOpen(false)}>{T('Close')}</button></div></div></div>}

      {feedbackChooserOpen && <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="feedback-choice-title" onClick={(event) => { if (event.target === event.currentTarget) setFeedbackChooserOpen(false); }} onKeyDown={(event) => { if (event.key === 'Escape') setFeedbackChooserOpen(false); }}><div className="modal quick-concern-modal">
        <div className="modal-header"><div><span className="eyebrow">{T('SAFETY REPORT')}</span><h2 id="feedback-choice-title">{T('feedback')} & {T('suggestion')}</h2><p>{T('Choose what you would like to share.')}</p></div><button className="close-button" type="button" onClick={() => setFeedbackChooserOpen(false)} aria-label={T('Close report choices')}><X /></button></div>
        <button type="button" className="report-chooser-back" onClick={() => backFromChooser('feedback')}><ArrowLeft size={16} aria-hidden="true" /> {T('Back')}</button>
        <div className="quick-concern-options">
          <button type="button" className="quick-concern-option" autoFocus onClick={() => { setFeedbackChooserOpen(false); openReport('Feedback'); }}><span className="tile-icon teal"><MessageSquare size={20} aria-hidden="true" /></span><span><b>{T('feedback')}</b><small>{T('Share your experience')}</small></span><ChevronRight size={18} aria-hidden="true" /></button>
          <button type="button" className="quick-concern-option" onClick={() => { setFeedbackChooserOpen(false); openReport('Suggestion'); }}><span className="tile-icon green"><Lightbulb size={20} aria-hidden="true" /></span><span><b>{T('suggestion')}</b><small>{T('Share a safer-work idea')}</small></span><ChevronRight size={18} aria-hidden="true" /></button>
        </div>
      </div></div>}

      {quickConcernChooserOpen && <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="quick-concern-title"><div className="modal quick-concern-modal">
        <div className="modal-header"><div><span className="eyebrow">{T('SAFETY REPORT')}</span><h2 id="quick-concern-title">{T('Grievance or Speak Up?')}</h2><p>{T('Choose a path. Both options can be anonymous.')}</p></div><button className="close-button" type="button" onClick={() => setQuickConcernChooserOpen(false)} aria-label={T('Close report choices')}><X /></button></div>
        <button type="button" className="report-chooser-back" onClick={() => backFromChooser('concern')}><ArrowLeft size={16} aria-hidden="true" /> {T('Back')}</button>
        <div className="quick-concern-options">
          <button type="button" className="quick-concern-option" onClick={() => { setQuickConcernChooserOpen(false); openReport('Grievance'); }}><span className="tile-icon purple"><MessageSquare size={20} /></span><span><b>{T('grievance')}</b><small>{T('Anonymous option available')}</small></span><ChevronRight size={18} /></button>
          <button type="button" className="quick-concern-option" onClick={() => { setQuickConcernChooserOpen(false); openReport('Speak Up'); }}><span className="tile-icon purple"><Shield size={20} /></span><span><b>{T('speakUp')}</b><small>{T('Anonymous option available')}</small></span><ChevronRight size={18} /></button>
        </div>
        <div className="modal-footnote"><LockKeyhole size={14} /> {T('Avoid identifying details in your description and photos.')}</div>
      </div></div>}

      {safetyAlertsOpen && <div className="safety-alerts-modal-shell" role="dialog" aria-modal="true" aria-labelledby="safety-alerts-modal-title" onTouchStart={handleSafetyAlertsTouchStart} onTouchEnd={handleSafetyAlertsTouchEnd}>
        <section className="safety-alerts-modal">
          <header className="safety-alerts-header">
            <button type="button" className="safety-alerts-back" onClick={handleSafetyAlertsBack} aria-label={T(expandedSafetyAlertId ? 'Back to all safety alerts' : 'Back')}><ArrowLeft size={20} /><span>{T('Back')}</span></button>
            <div className="safety-alerts-header-title"><h2 id="safety-alerts-modal-title">{T('Safety Alerts')}</h2><small>{currentSite?.name ?? T('Selected site')}</small></div>
            <button type="button" className="safety-alerts-close" onClick={closeSafetyAlerts} aria-label={T('Close safety alerts')}><X size={21} /></button>
          </header>
          <div className="safety-alerts-scroll" ref={safetyAlertsScrollRef}>
            <div className="safety-alert-filter-row" role="group" aria-label={T('Filter safety alerts')}>
              {SAFETY_ALERT_FILTERS.map((filter) => <button key={filter} type="button" className={`safety-alert-filter-chip ${safetyAlertFilter === filter ? 'active' : ''}`} aria-pressed={safetyAlertFilter === filter} onClick={() => { setSafetyAlertFilter(filter); setExpandedSafetyAlertId(null); }}>{T(filter)}</button>)}
            </div>
            <div className="safety-alerts-results-heading"><h3>{safetyAlertFilter === 'All' ? T('All safety alerts') : T(safetyAlertFilter)}</h3><span>{T('{count} alerts', { count: new Intl.NumberFormat(locale).format(filteredSafetyAlerts.length) })}</span></div>
            <div className="safety-alert-list">
              {filteredSafetyAlerts.map((alert) => {
                const expanded = expandedSafetyAlertId === alert.id;
                const categoryClass = alert.category.toLowerCase().replace(/\s+/g, '-');
                const detailsId = `safety-alert-details-${alert.id}`;
                return <article className={`safety-alert-card ${categoryClass} ${expanded ? 'expanded' : ''}`} key={alert.id}>
                  <button type="button" className="safety-alert-card-toggle" aria-expanded={expanded} aria-controls={detailsId} onClick={() => setExpandedSafetyAlertId((current) => current === alert.id ? null : alert.id)}>
                    <span className={`safety-alert-category-icon ${categoryClass}`}><AlertTriangle size={19} aria-hidden="true" /></span>
                    <span className="safety-alert-card-copy">
                      <span className="safety-alert-card-meta"><span className={`safety-alert-category-pill ${categoryClass}`}>{T(alert.category)}</span><time dateTime={alert.date}>{formatHomeFeedDate(alert.date, locale)} · {formatHomeFeedTime(alert.date, locale)}</time>{alert.attachment && <span className="safety-alert-file-chip">{alert.attachment.kind === 'pdf' ? 'PDF' : T('Photo')}</span>}</span>
                      <b>{alert.title}</b>
                      <span className="safety-alert-location"><MapPin size={14} aria-hidden="true" />{alert.site} · {alert.area}</span>
                    </span>
                    <ChevronDown size={19} className={`safety-alert-expand-icon ${expanded ? 'expanded' : ''}`} aria-hidden="true" />
                  </button>
                  <div id={detailsId} className={`safety-alert-details ${expanded ? 'expanded' : ''}`} aria-hidden={!expanded}>
                    <div className="safety-alert-details-inner">
                      <section><h4>{T('Incident description')}</h4><p>{alert.description}</p></section>
                      <section><h4>{T('Root cause')}</h4><p>{alert.rootCause}</p></section>
                      <section><h4>{T('Immediate response')}</h4><ul>{alert.immediateActions.map((action) => <li key={action}>{action}</li>)}</ul></section>
                      <section><h4>{T('Corrective actions')}</h4><ul>{alert.correctiveActions.map((action) => <li key={action}>{action}</li>)}</ul></section>
                      <section><h4>{T('Lessons learned')}</h4><ul>{alert.lessonsLearned.map((lesson) => <li key={lesson}>{lesson}</li>)}</ul></section>
                      {alert.attachment && expanded && (() => {
                        const inlineUrl = alert.attachment.kind === 'image'
                          ? appendResourceQuery(alert.attachment.url, 'inline', '1')
                          : appendResourceQuery(alert.attachment.url, 'inline', '1', 'navpanes=0&view=FitH');
                        const downloadUrl = appendResourceQuery(alert.attachment.url, 'download', '1');
                        if (!inlineUrl || !downloadUrl) return null;
                        return <section className="safety-alert-file">
                          <h4>{T('Incident file')}</h4>
                          {alert.attachment.kind === 'image'
                            ? <img
                              className="safety-alert-file-image"
                              src={inlineUrl}
                              alt={alert.attachment.name}
                              loading="lazy"
                              decoding="async"
                            />
                            : <div className="safety-alert-file-viewer">
                              <iframe
                                src={inlineUrl}
                                title={alert.attachment.name}
                                loading="lazy"
                              />
                            </div>}
                          <div className="safety-alert-file-actions">
                            <span>{alert.attachment.name}</span>
                            <a href={downloadUrl} download>{T('Download')}</a>
                          </div>
                        </section>;
                      })()}
                    </div>
                  </div>
                </article>;
              })}
              {filteredSafetyAlerts.length === 0 && <div className="safety-alerts-empty">{T('No safety alerts have been published for this site yet.')}</div>}
            </div>
          </div>
        </section>
      </div>}

      {reportPickerOpen && <div className="overlay report-picker-overlay" role="dialog" aria-modal="true" aria-labelledby="report-picker-title">
        <div className="modal report-picker-modal">
          <div className="report-picker-handle" aria-hidden="true"><span /></div>
          <div className="modal-header report-picker-header">
            <button type="button" className="workflow-back" onClick={() => setReportPickerOpen(false)} aria-label={T('Back')}><ArrowLeft size={20} aria-hidden="true" /></button>
            <h2 id="report-picker-title">{T('What would you like to report?')}</h2>
            <button className="close-button report-picker-close" type="button" onClick={() => setReportPickerOpen(false)} aria-label={T('Close report types')}><X /></button>
          </div>
          <div className="report-picker-grid">
            {DIRECT_REPORT_TILES.map((item) => {
              const Icon = item.icon;
              const title = `${item.id === 'unsafe-condition' ? 'UC · ' : item.id === 'unsafe-act' ? 'UA · ' : ''}${reportTileTitle(item)}${item.id === 'observation' ? ' (UC / UA)' : ''}`;
              return <button key={item.id} type="button" className="report-picker-option" aria-label={title} aria-haspopup={item.opensFeedbackChooser || item.opensConcernChooser ? 'dialog' : undefined} onClick={() => selectReportTile(item)}>
                <span className={`tile-icon ${item.tone}`}><Icon size={24} aria-hidden="true" /></span>
                <span className="report-picker-copy"><b>{title}</b><small className="sr-only">{T(item.descEn)}</small></span>
                {APP_FEATURES.voiceReporting && <span className="report-picker-voice" aria-hidden="true"><Mic size={22} /></span>}
              </button>;
            })}
          </div>
        </div>
      </div>}

      {reportType && currentSite && <ReportWorkflow key={`${reportType}-${currentSite.id}`} type={reportType} site={currentSite} directory={directory} language={language} onLanguageChange={setLanguage} voiceEnabled={APP_FEATURES.voiceReporting} onBack={backFromReport} onClose={() => setReportType(null)} onSubmit={submitReport} />}
      {profileSearchOpen && <ProfileSearchDialog site={currentSite} sites={displaySites} companyName={companyName} directory={directory} directoryMode={directoryMode} directoryReason={directoryReason} employeeCount={employeeCount} autoEmployeeId={qrEmployeeId ?? undefined} onClose={() => { setProfileSearchOpen(false); setQrEmployeeId(null); }} />}
      {moreInfoKind && <MoreInfoDialog kind={moreInfoKind} company={company} onClose={() => setMoreInfoKind(null)} onLogin={() => { setMoreInfoKind(null); setToast({ key: 'Login is unavailable in the UI preview.' }); }} />}


      {notificationsOpen && <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="notification-title" onClick={(event) => { if (event.target === event.currentTarget) setNotificationsOpen(false); }}><div className="modal settings-modal"><div className="modal-header"><div><span className="eyebrow">{T('DEVICE SETTINGS')}</span><h2 id="notification-title">{T('Push notifications')}</h2></div><button type="button" className="close-button" onClick={() => setNotificationsOpen(false)} aria-label={T('Close')}><X /></button></div><p>{T('Choose which published updates reach this device. Avoid sending every draft or internal edit.')}</p><div className="notification-status"><Bell size={17} /><span>{T('Browser permission:')} <b>{T(notificationPermission)}</b></span></div><Preference label="Safety Alerts and urgent notices" detail="New published safety alerts" checked={pushPrefs.safety} onChange={() => setPref('safety')} /><Preference label="Circulars and published updates" detail="Notices, events and training" checked={pushPrefs.notices} onChange={() => setPref('notices')} /><Preference label="My report status" detail="Updates only for your reports" checked={pushPrefs.ownReports} onChange={() => setPref('ownReports')} /><Preference label="All vendor-site updates" detail="Opt in for this vendor only" checked={pushPrefs.allVendorSites} onChange={() => setPref('allVendorSites')} /><Preference label="Hide details on lock screen" detail="Recommended for privacy" checked={pushPrefs.hideLockScreen} onChange={() => setPref('hideLockScreen')} /><button type="button" className="primary-button full-button" onClick={requestPushPermission}>{T('Allow notifications on this device')}</button></div></div>}

      {sosOpen && <div
        className="overlay sos-overlay"
        role="dialog"
        aria-modal="true"
        aria-labelledby="sos-title"
        onClick={(event) => { if (event.target === event.currentTarget) setSosOpen(false); }}
      >
        <div className="modal sos-modal">
          <div className="sos-hero">
            <span className="sos-hero-icon" aria-hidden="true"><PhoneCall size={30} /></span>
            <h2 id="sos-title"><span aria-hidden="true">🚨</span> {T('EMERGENCY HELPLINE')}</h2>
          </div>
          <div className="sos-body">
            <p className="sos-company">{T('Site emergency contact')}</p>
            {sosDialHref && sosNumber ? <>
              <p className="sos-number">{sosNumber}</p>
              <a className="sos-call-button" href={sosDialHref}>
                <PhoneCall size={20} aria-hidden="true" /> {T('Tap to Call')}
              </a>
              <div className="sos-note"><p>{T('Use this number only in an emergency.')}</p></div>
            </> : <div className="sos-note" role="status">
              <p>{T('No emergency contact is available for this site in the UI preview. Contact local emergency services directly if you need urgent help.')}</p>
            </div>}
            <button className="sos-cancel-button" type="button" onClick={() => setSosOpen(false)}>{T('Cancel')}</button>
          </div>
        </div>
      </div>}

      {feedDetail && <HomeFeedDetailDialog item={feedDetail} siteName={currentSite?.name ?? T('Selected site')} onClose={() => setFeedDetail(null)} />}

      {toast && <div className="toast" role="status">{T(toast.key, { ...toast.params, ...(toast.report ? { report: toast.report.category ? `${T(toast.report.type)} · ${T(toast.report.category)}` : T(toast.report.type) } : {}) })}</div>}
    </div>
  );
}

function NavItem({ active, icon, label, onClick }: { active: boolean; icon: ReactNode; label: string; onClick: () => void }) {
  const { T } = useI18n();
  return <button type="button" className={`nav-item ${active ? 'active' : ''}`} aria-current={active ? 'page' : undefined} onClick={onClick}>{icon}<span>{T(label)}</span></button>;
}

function Preference({ label, detail, checked, onChange }: { label: string; detail: string; checked: boolean; onChange: () => void }) {
  const { T } = useI18n();
  return <div className="preference-row"><div><b>{T(label)}</b><small>{T(detail)}</small></div><button type="button" className={`switch ${checked ? 'on' : ''}`} aria-label={T(label)} aria-pressed={checked} onClick={onChange}><span /></button></div>;
}

function PlusIcon() { return <span className="plus-symbol">+</span>; }
